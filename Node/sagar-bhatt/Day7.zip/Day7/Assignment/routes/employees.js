const chalk = require("chalk");
const express = require("express");

const router = express.Router();
router.use(express.json());

// * IMPORT employees.JSON
const employees = require("../data/employees.json");

// * IMPORT JOI VALIDATIONS
const { validateEmployee, validateAssignment } = require("../utils/validation");

// * IMPORT updateFile()
const updateFile = require("../utils/update-file");

// * HOME PAGE
router.get("/", (req, res, next) => {
  res.send(
    `<h3>Employees API</h3>
    <a href="http://localhost:3000/employees">http://localhost:3000/employees</a>`
  );
  next();
});

// * GET ALL EMPLOYEES
router.get("/employees", (req, res, next) => {
  res.send(employees);
  next();
});

// * GET AN EMPLOYEE
router.get("/employees/:id", (req, res, next) => {
  const employee = employees.find(
    (elem) => elem.EmployeeId === parseInt(req.params.id)
  );
  if (!employee) {
    console.error(
      chalk.red(
        JSON.stringify({
          status: 404,
          message: "Employee Not Found",
        })
      )
    );
    res.status(404).send({
      status: 404,
      message: "Employee Not Found",
    });
  } else {
    res.send(employee);
  }
  next();
});

// * Update AN EMPLOYEE
router.put("/employees/:id", (req, res, next) => {
  let employee = employees.find(
    (elem) => elem.EmployeeId === parseInt(req.params.id)
  );
  if (!employee) {
    console.error(
      chalk.red(
        JSON.stringify({
          status: 404,
          message: "Employee Not Found",
        })
      )
    );
    res.status(404).send({
      status: 404,
      message: "Employee Not Found",
    });
  } else {
    const { error } = validateEmployee(req.body);
    if (error) {
      console.error(chalk.red(error.details[0].message));
      res.send(`<h1 style="color:red;">${error.details[0].message}</h1>`);
    } else {
      const data = req.body;
      for (let key in data) {
        if (!Array.isArray(data[key])) {
          employee[key] = data[key];
        } else {
          if (typeof data[key][0] === "object") {
            for (let subKey in data[key][0]) {
              employee[key][0][subKey] = data[key][0][subKey];
            }
          } else {
            for (let subKey in data[key]) {
              employee[key][subKey] = data[key][subKey];
            }
          }
        }
      }
      updateFile("data/employees.json", employees).catch((err) => {
        console.error(err);
      });
      res.send(employee);
    }
  }
  next();
});

// * CREATE AN EMPLOYEE
router.post("/employees", (req, res, next) => {
  const data = req.body;
  const { error } = validateEmployee(data);
  if (error) {
    console.error(chalk.red(error.details[0].message));
    res.send(`<h1 style="color:red;">${error.details[0].message}</h1>`);
  } else {
    data.EmployeeId = employees.length + 1;
    employees.push(data);
    updateFile("data/employees.json", employees);
    res.send(data);
  }
  next();
});

// * DELETE AN EMPLOYEE
router.delete("/employees/:id", (req, res, next) => {
  const employee = employees.find(
    (elem) => elem.EmployeeId === parseInt(req.params.id)
  );
  if (!employee) {
    console.error(
      chalk.red(
        JSON.stringify({
          status: 404,
          message: "Employee Not Found",
        })
      )
    );
    res.status(404).send({
      status: 404,
      message: "Employee Not Found",
    });
  } else {
    const index = employees.indexOf(employee);
    employees.splice(index, 1);
    updateFile("data/employees.json", employees);
    res.send(employee);
  }
  next();
});

// * Create an Assignments API
// * Get All Assignments
// ? http://localhost:3000/emps/{empID}/child/assignments
router.get("/emps/:id/child/assignments", (req, res, next) => {
  const employee = employees.find(
    (elem) => elem.EmployeeId === parseInt(req.params.id)
  );
  if (!employee) {
    console.error(
      chalk.red(
        JSON.stringify({
          status: 404,
          message: "Employee Not Found",
        })
      )
    );
    res.status(404).send({
      status: 404,
      message: "Employee Not Found",
    });
  } else {
    res.send(employee.assignments);
  }
  next();
});

// * Get an Assignment
// ? http://localhost:3000/emps/{empID}/child/assignments/{AssignmentID}
router.get("/emps/:id/child/assignments/:AssignmentID", (req, res, next) => {
  const employee = employees.find(
    (elem) => elem.EmployeeId === parseInt(req.params.id)
  );
  const assignment = employees.find(
    (elem) =>
      elem.assignments[0].AssignmentId === parseInt(req.params.AssignmentID)
  );

  if (!employee) {
    console.error(
      chalk.red(
        JSON.stringify({
          status: 404,
          message: "Employee Not Found",
        })
      )
    );
    res.status(404).send({
      status: 404,
      message: "Employee Not Found",
    });
  } else if (!assignment) {
    console.error(
      chalk.red(
        JSON.stringify({
          status: 404,
          message: "Assignment Not Found",
        })
      )
    );
    res.status(404).send({
      status: 404,
      message: "Assignment Not Found",
    });
  } else {
    res.send(employee.assignments);
  }
  next();
});

// * Update an assignment
// ? http://localhost:3000/emps/{empID}/child/assignments/{AssignmentID}
router.put("/emps/:id/child/assignments/:AssignmentID", (req, res, next) => {
  const employee = employees.find(
    (elem) => elem.EmployeeId === parseInt(req.params.id)
  );
  const assignment = employees.find(
    (elem) =>
      elem.assignments[0].AssignmentId === parseInt(req.params.AssignmentID)
  );

  if (!employee) {
    console.error(
      chalk.red(
        JSON.stringify({
          status: 404,
          message: "Employee Not Found",
        })
      )
    );
    res.status(404).send({
      status: 404,
      message: "Employee Not Found",
    });
  } else if (!assignment) {
    console.error(
      chalk.red(
        JSON.stringify({
          status: 404,
          message: "Assignment Not Found",
        })
      )
    );
    res.status(404).send({
      status: 404,
      message: "Assignment Not Found",
    });
  } else {
    const { error } = validateAssignment(req.body);
    if (error) {
      console.error(chalk.red(error.details[0].message));
      res.send(`<h1 style="color:red;">${error.details[0].message}</h1>`);
    } else {
      const data = req.body;
      for (let key in data) {
        employee["assignments"][0][key] = data[key];
      }
      updateFile("data/employees.json", employees).catch((err) => {
        console.error(err);
      });
      res.send(employee);
    }
  }
  next();
});

// * Error Handling Middleware
// router.use((req, res, next) => {
//   next(err);
// });

// router.use((err, req, res, next) => {
//   console.error(
//     chalk.red(
//       JSON.stringify({
//         status: 404,
//         message: "Page Not Found",
//       })
//     )
//   );
//   res.status(404).send({
//     status: 404,
//     message: "Page Not Found",
//   });
// });
module.exports = router;
